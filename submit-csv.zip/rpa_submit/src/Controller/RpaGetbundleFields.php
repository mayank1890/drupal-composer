<?php
/**
 * @file
 */
namespace Drupal\rpa_submit\Controller;

use Drupal\Core\Entity\EntityType;
use Drupal\Core\Field\FieldDefinitionInterface;
use Drupal\Core\DependencyInjection\ContainerBuilder;
use Drupal\Core\Entity\EntityFieldManagerInterface;
use Drupal\Core\Entity\EntityManager;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\field\Entity\FieldConfig;



class RpaGetbundleFields extends ControllerBase {

 /**
   * The entity field manager.
   *
   * @var \Drupal\Core\Entity\EntityFieldManager
   */
  protected $entityFieldManager;

  /**
   * Constructor.
   *
   * @param \Drupal\Core\Entity\EntityFieldManager $entity_field_manager
   *   The entity field manager.
   */
  public function __construct(EntityFieldManager $entity_field_manager) {
    $this->entityFieldManager = $entity_field_manager;
  }


   /**
   * Build table rows.
   */
  public function buildRows($entity_type_id='',$bundle='') {
	$fields = $this->entityFieldManager->getFieldDefinitions($entity_type_id, $bundle);
	foreach ($fields as $field_name => $field_definition) {
	  if (!empty($field_definition->getTargetBundle())) {               
		$listFields[$field_name]['type'] = $field_definition->getType();
		$listFields[$field_name]['label'] = $field_definition->getLabel();                  
	  }
	}
	$rows = [];
	foreach ($listFields as $field_name => $info) {
	  $rows[] = $this->buildRow($info, $field_name);
	}
	return $rows;
 }
  
}